#!/usr/bin/env python3
"""Corporate Spec-Kit Pre-Flight Air-Gap Integrity Verifier.
Zero external dependencies; standard Python library only.
Used by corporate security and audit teams to verify cryptographic checksums
before deployment on intranet / air-gapped systems.
"""
import os
import sys
import hashlib

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def sha256_file(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    sums_file = os.path.join(base_dir, "SHA256SUMS.txt")

    if not os.path.exists(sums_file):
        print(f"[!] Error: Checksums file not found at: {sums_file}")
        sys.exit(1)

    print("=" * 80)
    print("   CORPORATE SPEC-KIT AIR-GAP PRE-FLIGHT INTEGRITY VERIFICATION")
    print(f"   Manifest: {sums_file}")
    print("=" * 80 + "\n")

    total = 0
    passed = 0
    failed = 0
    missing = 0

    with open(sums_file, "r", encoding="utf-8") as f:
        lines = f.readlines()

    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            continue
        expected_hash, rel_path = parts
        rel_path = rel_path.lstrip("*").strip()
        full_path = os.path.join(base_dir, *rel_path.split("/"))

        total += 1
        if not os.path.exists(full_path):
            print(f"  [MISSING]  {rel_path}")
            missing += 1
            continue

        actual_hash = sha256_file(full_path)
        if actual_hash.lower() == expected_hash.lower():
            print(f"  [OK]       {rel_path}")
            passed += 1
        else:
            print(f"  [TAMPERED] {rel_path}")
            print(f"             Expected: {expected_hash}")
            print(f"             Actual:   {actual_hash}")
            failed += 1

    print("\n" + "=" * 80)
    if failed == 0 and missing == 0 and total > 0:
        print(f"   [OK] INTEGRITY AUDIT PASSED: {passed}/{total} files verified.")
        print("   Status: UNCOMPROMISED (Air-Gapped Bundle Sealed & Valid)")
        print("=" * 80 + "\n")
        sys.exit(0)
    else:
        print(f"   [FAIL] INTEGRITY AUDIT FAILED!")
        print(f"   Passed: {passed} | Tampered: {failed} | Missing: {missing} | Total: {total}")
        print("   DO NOT PROCEED with launch. Contact Corporate Information Security.")
        print("=" * 80 + "\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
